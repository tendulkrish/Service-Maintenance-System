﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SM.Models
{
    public partial class Products
    {
        public int ProductId { get; set; }

        [Required]
        [Display(Name = "Product Code")]
        public string ProductCode { get; set; }

        [Required]
        [Display(Name = "Product Name")]
        public string ProductName { get; set; }
        public string Pdescription { get; set; }

        [Required]
        [Display(Name = "Service Period")]
        public int ServicePeriodId { get; set; }

        [Required]
        [Display(Name = "Product Price")]
        public double? ProductPrice { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? Pstatus { get; set; }
    }
}
