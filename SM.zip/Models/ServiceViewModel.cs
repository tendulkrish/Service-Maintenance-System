﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SM.Models;
using X.PagedList;

namespace SM.Models
{
    public class ServiceViewModel
    {
        public ServiceInfo serviceInfo { get; set; }
        public IPagedList<ServiceInfo> serviceInfolist { get; set; }
        public List<SelectListItem> customerlist { set; get; }
        public List<SelectListItem> productlist { set; get; }
        public List<SelectListItem> serviceperiods { set; get; }
    }
}
