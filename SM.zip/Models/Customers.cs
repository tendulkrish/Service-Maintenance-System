﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SM.Models
{
    public partial class Customers
    {
        public int CustomerId { get; set; }
        public string BillNo { get; set; }

        [Required]
        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }

        [Display(Name = "Mobile Number")]
        public string MobileNumber { get; set; }

        [Display(Name = "Address")]
        public string Caddress { get; set; }

        [Display(Name = "Product Name")]
        public int? ProductId { get; set; }

        [Display(Name = "Selling Price")]
        public double? SellingPrice { get; set; }

        [Display(Name = "Sales Person")]
        public string SalesPerson { get; set; }

        [Display(Name = "Installation Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? InstallationDate { get; set; }

        public DateTime? CreateDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? Cstatus { get; set; }
    }
}
