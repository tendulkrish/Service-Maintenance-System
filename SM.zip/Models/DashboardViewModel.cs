﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using X.PagedList;

namespace SM.Models
{
    public class DashboardViewModel
    {
        public IPagedList<ServiceOutput> Servicelist { get; set; }
        public ServiceOutput serviceOutput { get; set; }
    }

    public class ServiceOutput
    {
        [Display(Name ="Customer Name")]
        public string CustomerName { get; set; }
        [Display(Name = "Product Name")]
        public string ProductName { get; set; }
        [Display(Name = "Mobile Number")]
        public string MobileNumber { get; set; }
        [Display(Name = "Installation Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? InstallationDate { get; set; }
        [Display(Name = "Next Service Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? NextServiceDate { get; set; }
    }
}
