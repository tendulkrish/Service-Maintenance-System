﻿using System;
using System.Collections.Generic;

namespace SM.Models
{
    public partial class ServiceMessages
    {
        public int MessageId { get; set; }
        public string MessageText { get; set; }
        public int? CustomerId { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? Smstatus { get; set; }
    }
}
