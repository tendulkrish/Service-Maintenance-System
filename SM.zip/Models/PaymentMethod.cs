﻿using System;
using System.Collections.Generic;

namespace SM.Models
{
    public partial class PaymentMethod
    {
        public int PaymentId { get; set; }
        public string PaymentName { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? Pstatus { get; set; }
    }
}
