using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using SM.DBEntities;
using X.PagedList;
namespace SM.Models
{
    public class CustomerViewModel
    {
        public Customers Customer { get; set; }
        public IPagedList<Customers> Customerlist { get; set; }
        public List<SelectListItem> productlist { set; get; }
    }
}
