﻿using System;
using System.Collections.Generic;

namespace SM.Models
{
    public partial class ServicePeriods
    {
        public int PeriodId { get; set; }
        public string PeriodName { get; set; }
        public DateTime? Createddate { get; set; }
        public bool? Mstatus { get; set; }
        public int? PeriodMonth { get; set; }
    }
}
