﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SM.Models
{
    public partial class ServiceInfo
    {
        public int ServiceId { get; set; }

        [Required]
        [Display(Name ="Customer Name")]
        public int? CustomerId { get; set; }
        [Display(Name = "Product Name")]
        public int? ProductId { get; set; }
        [Display(Name = "Service No")]
        public int? ServiceNo { get; set; }

        [Display(Name = "Visited Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? VisitedDate { get; set; }
        [Display(Name = "Technician Name")]
        public string TechnicianName { get; set; }
        public string SpareDetails { get; set; }
        [Display(Name = "Next Service Period")]
        public int? NextServicePeriodId { get; set; }
        public string WorkDescription { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? Sstatus { get; set; }
    }
}
