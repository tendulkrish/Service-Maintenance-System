using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SM.Models;
using SM.DBEntities;
using X.PagedList;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;
/// <summary>
/// Created By: tendulkrish
/// </summary>
namespace SM.Controllers
{
    [Authorize]
    public class CustomersController : Controller
    {
        private SM_DBContext _smdbcontext;

        public CustomersController(SM_DBContext smdbContext)
        {
            _smdbcontext = smdbContext;
        }

        public async Task<ActionResult> Index(int? pagenumber)
        {
            int billno = 1;
            int pagesize = 5, pageindex = pagenumber.HasValue ? Convert.ToInt32(pagenumber) : 1;
            CustomerViewModel customervm = new CustomerViewModel();
            customervm.Customer = new Customers();
            customervm.Customerlist = null;

            List<Customers> listcustomers = GetCustomers(ref billno);
            customervm.Customer.BillNo = billno.ToString();

            List<SelectListItem> selectproudcts = new List<SelectListItem>();
            var products = GetProducts();
            foreach (var item in products)
            {
                SelectListItem selectList = new SelectListItem
                {
                    Text = item.ProductCode + " - " + item.ProductName,
                    Value = item.ProductId.ToString()
                };
                selectproudcts.Add(selectList);
            }

            customervm.Customerlist = await listcustomers.ToPagedListAsync<Customers>(pageindex, pagesize);
            customervm.productlist = selectproudcts;
            return View(customervm);

        }

        [HttpPost]
        public ActionResult CreateCustomer(CustomerViewModel customervm, string actiontype)
        {
            if (ModelState.IsValid)
            {
                if (actiontype == "Save")
                {
                    Customers newcustomer = customervm.Customer;
                    AddCustomer(newcustomer);
                }
                else if (actiontype == "Update")
                {
                    Customers updatecustomer = customervm.Customer;
                    UpdateCustomer(updatecustomer);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult EditCustomer(string customerid)
        {
            var customers = EditCustomerDB(customerid);
            return Json(customers);
        }

        [HttpPost]
        public ActionResult DeleteCustomer(string customerid)
        {
            DeleteCustomerDB(customerid);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<ActionResult> GetProductInfo(string productid)
        {
            int prodid = Convert.ToInt32(productid);
            var products = from S in _smdbcontext.Products
                           where S.ProductId == prodid
                           select new
                           {
                               S.ProductId,
                               S.ProductPrice
                           };
            var prod = products.SingleOrDefault();
            var obj = new { value = prod.ProductId, data = prod.ProductPrice };
            return Json(obj);
        }

        [NonAction]
        public List<Customers> GetCustomers(ref int billno)
        {

            List<Customers> listcustomers = new List<Customers>();
            var customers = _smdbcontext.Customers.ToList();
            if (customers != null && customers.Count > 0)
            {
                listcustomers = _smdbcontext.Customers.ToList();
                billno = _smdbcontext.Customers.Max(m => m.CustomerId) + 1;
            }
            return listcustomers;
        }

        [NonAction]
        public IQueryable<Products> GetProducts()
        {
            IQueryable<Products> products = from S in _smdbcontext.Products
                                            select S;
            return products;
        }

        [NonAction]
        public void AddCustomer(Customers newcustomer)
        {
            _smdbcontext.Customers.Add(newcustomer);
            _smdbcontext.SaveChanges();
        }

        [NonAction]
        public void UpdateCustomer(Customers updatecustomer)
        {
            var oldcustomer = _smdbcontext.Customers.Single(m => m.CustomerId == updatecustomer.CustomerId);
            if (oldcustomer != null && oldcustomer.CustomerId > 0)
            {
                oldcustomer.CustomerName = updatecustomer.CustomerName;
                oldcustomer.ProductId = updatecustomer.ProductId;
                oldcustomer.MobileNumber = updatecustomer.MobileNumber;
                oldcustomer.InstallationDate = updatecustomer.InstallationDate;
                oldcustomer.SalesPerson = updatecustomer.SalesPerson;
                oldcustomer.Caddress = updatecustomer.Caddress;
                _smdbcontext.Customers.Update(oldcustomer);
                _smdbcontext.SaveChanges();
            }
        }

        [NonAction]
        public dynamic EditCustomerDB(string customerid)
        {
            dynamic customer = from C in _smdbcontext.Customers
                               where C.CustomerId == Convert.ToInt32(customerid)
                               select new
                               {
                                   C.BillNo,
                                   C.CustomerName,
                                   C.CustomerId,
                                   C.Caddress,
                                   C.InstallationDate,
                                   C.MobileNumber,
                                   C.ProductId,
                                   C.SalesPerson,
                                   C.SellingPrice
                               };
            return customer;
        }

        [NonAction]
        public void DeleteCustomerDB(string customerid)
        {
            Customers customers = _smdbcontext.Customers.Single(m => m.CustomerId == Convert.ToInt32(customerid));
            _smdbcontext.Customers.Remove(customers);
            _smdbcontext.SaveChanges();
        }
    }
}