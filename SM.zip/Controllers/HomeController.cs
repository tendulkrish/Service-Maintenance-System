﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SM.Models;
using System.Security;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
/// <summary>
/// Created By: tendulkrish
/// </summary>
namespace SM.Controllers
{
    public class HomeController : Controller
    {
        private string Username = "Admin";
        private string Password = "Admin";
        public IActionResult Index()
        {
            LoginViewModel loginViewModel = new LoginViewModel();
            return View(loginViewModel);
        }

        public async Task<IActionResult> Login(LoginViewModel loginViewModel)
        {
            if (ModelState.IsValid)
            {
                TempData["message"] = null;
                if (loginViewModel.Username == Username && loginViewModel.Password == Password)
                {
                    var claimsidentity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme, ClaimTypes.Name, "login");
                    claimsidentity.AddClaim(new Claim(ClaimTypes.Name, Username));
                    ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal(claimsidentity);

                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);
                    return RedirectToAction("Index", "Dashboard");
                }
                else
                {
                    TempData["message"] = "Login failed, Username or password incorrect";
                }
            }
            return View("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Index");
        }
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
