using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SM.Models;
using SM.DBEntities;
using Microsoft.AspNetCore.Mvc.Rendering;
using X.PagedList;
using Microsoft.AspNetCore.Authorization;
/// <summary>
/// Created By: tendulkrish
/// </summary>
namespace SM.Controllers
{
    [Authorize]
    public class ProductsController : Controller
    {
        private SM_DBContext _smdbcontext;

        public ProductsController(SM_DBContext smdbContext)
        {
            _smdbcontext = smdbContext;
        }

        [NonAction]
        private List<Products> GetProductsList()
        {
            List<Products> productLists = new List<Products>();
            if (_smdbcontext.Products.ToList() != null)
            {
                productLists = _smdbcontext.Products.ToList();
            }
            return productLists;
        }

        [NonAction]
        private List<SelectListItem> GetServicePeriods()
        {
            List<SelectListItem> selectServicePeriods = new List<SelectListItem>();
            var serviceperiod = from S in _smdbcontext.ServicePeriods
                                select S;
            foreach (var item in serviceperiod)
            {
                SelectListItem selectList = new SelectListItem
                {
                    Text = item.PeriodName,
                    Value = item.PeriodId.ToString()
                };
                selectServicePeriods.Add(selectList);
            }
            return selectServicePeriods;
        }

        [NonAction]
        private void AddProductsDB(Products products)
        {
            _smdbcontext.Products.Add(products);
            _smdbcontext.SaveChanges();
        }
        [NonAction]
        private void UpdateProductsDB(Products products)
        {
            var oldproduct = _smdbcontext.Products.SingleOrDefault(m => m.ProductId == products.ProductId);
            if (oldproduct != null && oldproduct.ProductId > 0)
            {
                oldproduct.ProductId = products.ProductId;
                oldproduct.ProductCode = products.ProductCode;
                oldproduct.ProductName = products.ProductName;
                oldproduct.Pdescription = products.Pdescription;
                oldproduct.ProductPrice = products.ProductPrice;
                _smdbcontext.Products.Update(oldproduct);
                _smdbcontext.SaveChanges();
            }
        }

        [NonAction]
        private void DeleteProductDB(string productid)
        {
            Products products = _smdbcontext.Products.Single(m => m.ProductId == Convert.ToInt32(productid));
            _smdbcontext.Products.Remove(products);
            _smdbcontext.SaveChanges();
        }

        [NonAction]
        private dynamic EditProductDB(string productid)
        {
            dynamic product = from P in _smdbcontext.Products
                              where P.ProductId == Convert.ToInt32(productid)
                              select new
                              {
                                  P.ProductId,
                                  P.ProductName,
                                  P.ProductCode,
                                  P.Pdescription,
                                  P.ProductPrice,
                                  P.ServicePeriodId
                              };
            return product;
        }

        public async Task<ActionResult> Index(int? pagenumber)
        {
            int pagesize = 5, pageindex = pagenumber.HasValue ? Convert.ToInt32(pagenumber) : 1;
            ProductViewModel productvm = new ProductViewModel();
            List<Products> productLists = GetProductsList();
            List<SelectListItem> selectServicePeriods = GetServicePeriods();
            productvm.productslist = await productLists.ToPagedListAsync<Products>(pageindex, pagesize);
            productvm.products = new Products();
            productvm.serviceperiods = selectServicePeriods;
            return View(productvm);
        }

        [HttpPost]
        public ActionResult AddProducts(ProductViewModel productViewModel, string actiontype)
        {
            if (ModelState.IsValid)
            {
                if (actiontype == "Save")
                {
                    AddProductsDB(productViewModel.products);
                }
                else if (actiontype == "Update")
                {
                    UpdateProductsDB(productViewModel.products);
                }
            }
            return RedirectToAction("Index", "Products");
        }

        [HttpGet]
        public ActionResult EditProduct(string productid)
        {
            dynamic products = EditProductDB(productid);
            return Json(products);
        }

        [HttpPost]
        public ActionResult DeleteProduct(string productid)
        {
            DeleteProductDB(productid);
            return RedirectToAction("Index");
        }
    }
}