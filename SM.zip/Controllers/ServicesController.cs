using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SM.DBEntities;
using SM.Models;
using X.PagedList;
/// <summary>
/// Created By: tendulkrish
/// </summary>
namespace SM.Controllers
{
    [Authorize]
    public class ServicesController : Controller
    {
        private SM_DBContext _smdbcontext;

        public ServicesController(SM_DBContext smdbContext)
        {
            _smdbcontext = smdbContext;
        }

        [NonAction]
        private dynamic GetProductinfoDB(string customerid)
        {
            var productid = from C in _smdbcontext.Customers
                            where C.CustomerId == Convert.ToInt32(customerid)
                            select new
                            {
                                C.ProductId
                            };
            int prodid = Convert.ToInt32(productid.SingleOrDefault().ProductId);
            var products = from S in _smdbcontext.Products
                           where S.ProductId == prodid
                           select new
                           {
                               S.ProductId,
                               S.ProductName,
                               S.ProductCode
                           };
            var prod = products.SingleOrDefault();
            dynamic jsonobject = new { value = prod.ProductId, data = prod.ProductName };
            return jsonobject;
        }

        [NonAction]
        private List<SelectListItem> selectcustomersDB()
        {
            List<SelectListItem> selectcustomers = new List<SelectListItem>();
            var customers = from S in _smdbcontext.Customers
                            select S;
            foreach (var item in customers)
            {
                SelectListItem selectList = new SelectListItem
                {
                    Text = item.CustomerName,
                    Value = item.CustomerId.ToString()
                };
                selectcustomers.Add(selectList);
            }
            return selectcustomers;
        }

        [NonAction]
        private List<SelectListItem> selectproductsDB()
        {
            List<SelectListItem> selectproudcts = new List<SelectListItem>();
            var products = from S in _smdbcontext.Products
                           select S;
            foreach (var item in products)
            {
                SelectListItem selectList = new SelectListItem
                {
                    Text = item.ProductCode + " - " + item.ProductName,
                    Value = item.ProductId.ToString()
                };
                selectproudcts.Add(selectList);
            }
            return selectproudcts;
        }

        [NonAction]
        private List<SelectListItem> selectserviceperiodsDB()
        {
            List<SelectListItem> selectServicePeriods = new List<SelectListItem>();
            var serviceperiod = from S in _smdbcontext.ServicePeriods
                                select S;
            foreach (var item in serviceperiod)
            {
                SelectListItem selectList = new SelectListItem
                {
                    Text = item.PeriodName,
                    Value = item.PeriodId.ToString()
                };

                selectServicePeriods.Add(selectList);
            }
            return selectServicePeriods;
        }

        [NonAction]
        private List<ServiceInfo> servicelistDB()
        {
            List<ServiceInfo> servicelist = new List<ServiceInfo>();
            if (_smdbcontext.ServiceInfo.ToList() != null && _smdbcontext.ServiceInfo.ToList().Count > 0)
            {
                servicelist = _smdbcontext.ServiceInfo.ToList();

            }
            return servicelist;
        }

        [NonAction]
        private void AddServiceDB(ServiceInfo newserviceInfo)
        {
            _smdbcontext.ServiceInfo.Add(newserviceInfo);
            _smdbcontext.SaveChanges();
        }

        [NonAction]
        private void UpdateServiceDB(ServiceInfo serviceInfo)
        {
            ServiceInfo oldnewserviceInfo = _smdbcontext.ServiceInfo.Single(m => m.ServiceId == serviceInfo.ServiceId);
            if (oldnewserviceInfo != null)
            {
                oldnewserviceInfo.ServiceId = serviceInfo.ServiceId;
                oldnewserviceInfo.ServiceNo = serviceInfo.ServiceNo;
                oldnewserviceInfo.CustomerId = serviceInfo.CustomerId;
                oldnewserviceInfo.NextServicePeriodId = serviceInfo.NextServicePeriodId;
                oldnewserviceInfo.ProductId = serviceInfo.ProductId;
                oldnewserviceInfo.SpareDetails = serviceInfo.SpareDetails;
                oldnewserviceInfo.VisitedDate = serviceInfo.VisitedDate;
                oldnewserviceInfo.WorkDescription = serviceInfo.WorkDescription;
                oldnewserviceInfo.TechnicianName = serviceInfo.TechnicianName;
                _smdbcontext.ServiceInfo.Update(oldnewserviceInfo);
                _smdbcontext.SaveChanges();
            }
        }

        [NonAction]
        private dynamic EditServiceDB(string serviceid)
        {
            dynamic services = from S in _smdbcontext.ServiceInfo
                               join P in _smdbcontext.Products on S.ProductId equals P.ProductId
                               where S.ServiceId == Convert.ToInt32(serviceid)
                               select new
                               {
                                   S.ServiceId,
                                   S.ServiceNo,
                                   S.CustomerId,
                                   P.ProductId,
                                   P.ProductName,
                                   S.NextServicePeriodId,
                                   S.SpareDetails,
                                   S.TechnicianName,
                                   S.VisitedDate,
                                   S.WorkDescription
                               }; return services;
        }

        [NonAction]
        private void DeleteServiceDB(string serviceid)
        {
            ServiceInfo serviceinfo = _smdbcontext.ServiceInfo.Single(m => m.ServiceId == Convert.ToInt32(serviceid));
            _smdbcontext.ServiceInfo.Remove(serviceinfo);
            _smdbcontext.SaveChanges();
        }

        [HttpGet]
        public ActionResult GetProductInfo(string customerid)
        {
            dynamic obj = GetProductinfoDB(customerid);
            return Json(obj);
        }

        public async Task<ActionResult> Index(int? pagenumber)
        {
            int serviceNo = 1;
            int pagesize = 5, pageindex = pagenumber.HasValue ? Convert.ToInt32(pagenumber) : 1;
            ServiceViewModel servicevm = new ServiceViewModel();
            servicevm.serviceInfo = new ServiceInfo();
            servicevm.serviceInfolist = null;

            List<ServiceInfo> serviceInfos = servicelistDB();
            if (serviceInfos.Count() > 0)
            {
                serviceNo = _smdbcontext.ServiceInfo.Max(m => m.ServiceId) + 1;
            }

            servicevm.serviceInfo.ServiceNo = serviceNo;
            servicevm.serviceInfolist = await serviceInfos.ToPagedListAsync<ServiceInfo>(pageindex, pagesize);
            servicevm.customerlist = selectcustomersDB();
            servicevm.productlist = selectproductsDB();
            servicevm.serviceperiods = selectserviceperiodsDB();
            return View(servicevm);

        }

        [HttpPost]
        public ActionResult CreateServiceInfo(ServiceViewModel servicevm, string actiontype)
        {
            if (actiontype == "Save")
            {
                AddServiceDB(servicevm.serviceInfo);
            }
            else if (actiontype == "Update")
            {
                UpdateServiceDB(servicevm.serviceInfo);
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult EditService(string serviceid)
        {
            dynamic services = EditServiceDB(serviceid);
            return Json(services);
        }

        [HttpPost]
        public ActionResult DeleteService(string serviceid)
        {
            DeleteServiceDB(serviceid);
            return RedirectToAction("Index");
        }
    }
}