using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SM.DBEntities;
using SM.Models;
using X.PagedList;
/// <summary>
/// Created By: tendulkrish
/// </summary>
namespace SM.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        public enum Chartdata
        {
            Product, Customer
        }
        private SM_DBContext _smdbcontext;

        public DashboardController(SM_DBContext smdbContext)
        {
            _smdbcontext = smdbContext;
        }

        public async Task<ActionResult> Index(int? pagenumber)
        {
            DateTime dtMonth = DateTime.Today;
            dynamic thismonthdata = GetThisMonthdata();
            int pagesize = 5, pageindex = pagenumber.HasValue ? Convert.ToInt32(pagenumber) : 1;
            DashboardViewModel dashvm = new DashboardViewModel();
            List<ServiceOutput> serviceOutputslst = new List<ServiceOutput>();
            foreach (var item in thismonthdata)
            {
                ServiceOutput serviceOutput = new ServiceOutput();
                serviceOutput.CustomerName = item.CustomerName;
                serviceOutput.ProductName = item.ProductName;
                serviceOutput.MobileNumber = item.MobileNumber;
                serviceOutput.InstallationDate = item.InstallationDate;
                serviceOutput.NextServiceDate = item.NextServiceDate;
                if (dtMonth.Month == serviceOutput.NextServiceDate.Value.Month &&
                    dtMonth.Year == serviceOutput.NextServiceDate.Value.Year)
                {
                    serviceOutputslst.Add(serviceOutput);
                }
            }
            dashvm.Servicelist = await serviceOutputslst.ToPagedListAsync<ServiceOutput>(pageindex, pagesize);
            return View(dashvm);

        }


        public ActionResult GetProductChartdata()
        {
            return jsondata(Chartdata.Product);
        }

        public ActionResult GetCustomerChartdata()
        {
            return jsondata(Chartdata.Customer);
        }

        public dynamic GetThisMonthdata()
        {
            dynamic thismonthdata = (from CCC in (from CC in (from C in _smdbcontext.Customers
                                                              join P in _smdbcontext.Products on C.ProductId equals P.ProductId
                                                              select new { C.CustomerId, C.CustomerName, C.MobileNumber, P.ProductId, P.ProductCode, P.ProductName, C.InstallationDate, P.ServicePeriodId })
                                                  join S in _smdbcontext.ServicePeriods on CC.ServicePeriodId equals S.PeriodId
                                                  select new
                                                  {
                                                      CC.CustomerId,
                                                      CC.CustomerName,
                                                      CC.MobileNumber,
                                                      CC.ProductId,
                                                      CC.ProductCode,
                                                      CC.ProductName,
                                                      CC.InstallationDate,
                                                      CC.ServicePeriodId,
                                                      S.PeriodMonth
                                                  })
                                     join
                                     SI in (from S in _smdbcontext.ServiceInfo
                                            join SS in _smdbcontext.ServicePeriods on S.NextServicePeriodId equals SS.PeriodId
                                            select new { S.CustomerId, S.ProductId, S.VisitedDate, S.NextServicePeriodId, SS.PeriodMonth })
                                     on new { C1 = (int?)CCC.CustomerId, C2 = (int?)CCC.ProductId } equals new { C1 = SI.CustomerId, C2 = SI.ProductId }
                                     into ps
                                     from SI in ps.DefaultIfEmpty()
                                     select new
                                     {
                                         CCC.CustomerName,
                                         CCC.ProductName,
                                         CCC.MobileNumber,
                                         CCC.InstallationDate,
                                         NextServiceDate = SI.VisitedDate != null ? SI.VisitedDate.Value.AddMonths((int)SI.PeriodMonth) : CCC.InstallationDate.Value.AddMonths((int)CCC.PeriodMonth)
                                     }).ToList();


            return thismonthdata;
        }
        [NonAction]
        public JsonResult jsondata(Chartdata chartdata)
        {
            List<object> lstproduct = new List<object>();
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Data1", System.Type.GetType("System.String"));
            dataTable.Columns.Add("Data2", System.Type.GetType("System.Int32"));
            if (chartdata == Chartdata.Product)
            {
                GenerateProductChart(ref dataTable);
            }
            else if (chartdata == Chartdata.Customer)
            {
                GenerateCustomerChart(ref dataTable);
            }
            foreach (DataColumn dc in dataTable.Columns)
            {
                List<object> x = new List<object>();
                x = (from DataRow drr in dataTable.Rows select drr[dc.ColumnName]).ToList();
                lstproduct.Add(x);
            }
            return Json(lstproduct);
        }

        [NonAction]
        public void GenerateProductChart(ref DataTable dataTable)
        {
            double? sminimumprice = (from c in _smdbcontext.Products select (double)c.ProductPrice).Min();
            double? smaximumprice = (from c in _smdbcontext.Products select (double)c.ProductPrice).Max();

            //double? sminimumprice = 0;
            decimal maximumprice = Convert.ToDecimal(smaximumprice);
            decimal minimumprice = Convert.ToDecimal(sminimumprice);
            decimal midprice = maximumprice / 5;

            decimal prevprice = 0;
            for (decimal currentprice = minimumprice; currentprice < maximumprice; currentprice++)
            {
                prevprice = currentprice;

                currentprice = currentprice + midprice;
                var prodcount = _smdbcontext.Products
                        .Where(m => Convert.ToInt64(m.ProductPrice) < currentprice && Convert.ToInt64(m.ProductPrice) >= prevprice).Count();
                DataRow dr = dataTable.NewRow();

                dr["Data1"] = prevprice;
                dr["Data2"] = prodcount;
                dataTable.Rows.Add(dr);
            }
        }

        [NonAction]
        public void GenerateCustomerChart(ref DataTable dataTable)
        {
            double? sminimumprice = (from c in _smdbcontext.Customers select (double)c.SellingPrice).Min();
            double? smaximumprice = (from c in _smdbcontext.Customers select (double)c.SellingPrice).Max();

            decimal maximumprice = Convert.ToDecimal(smaximumprice);
            decimal minimumprice = Convert.ToDecimal(sminimumprice);
            decimal midprice = maximumprice / 5;

            decimal prevprice = 0;
            for (decimal currentprice = minimumprice; currentprice < maximumprice; currentprice++)
            {
                prevprice = currentprice;

                currentprice = currentprice + midprice;
                var prodcount = _smdbcontext.Customers
                        .Where(m => Convert.ToInt64(m.SellingPrice) < currentprice && Convert.ToInt64(m.SellingPrice) >= prevprice).Count();
                DataRow dr = dataTable.NewRow();

                dr["Data1"] = prevprice;
                dr["Data2"] = prodcount;
                dataTable.Rows.Add(dr);
            }
            //decimal nextprice = 0;
            //decimal currprice = 0;
            //for (decimal i = 0; i < 5; i++)
            //{
            //    nextprice = nextprice + midamount;
            //    var prodcount = _smdbcontext.Customers
            //            .Where(m => Convert.ToInt64(m.SellingPrice) <= nextprice && Convert.ToInt64(m.SellingPrice) > currprice).Count();
            //    DataRow dr = dataTable.NewRow();

            //    dr["Data1"] = nextprice;
            //    dr["Data2"] = prodcount;
            //    dataTable.Rows.Add(dr);
            //    currprice = nextprice;
            //}
        }
    }
}