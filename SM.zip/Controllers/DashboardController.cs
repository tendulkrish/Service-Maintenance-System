using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SM.DBEntities;
using SM.Models;
/// <summary>
/// Created By: tendulkrish
/// </summary>
namespace SM.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        public enum Chartdata
        {
            Product, Customer
        }
        private SM_DBContext _smdbcontext;

        public DashboardController(SM_DBContext smdbContext)
        {
            _smdbcontext = smdbContext;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetProductChartdata()
        {
            return jsondata(Chartdata.Product);
        }

        public ActionResult GetCustomerChartdata()
        {
            return jsondata(Chartdata.Customer);
        }

        [NonAction]
        public JsonResult jsondata(Chartdata chartdata)
        {
            List<object> lstproduct = new List<object>();
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Data1", System.Type.GetType("System.String"));
            dataTable.Columns.Add("Data2", System.Type.GetType("System.Int32"));
            if (chartdata == Chartdata.Product)
            {
                GenerateProductChart(ref dataTable);
            }
            else if (chartdata == Chartdata.Customer)
            {
                GenerateCustomerChart(ref dataTable);
            }
            foreach (DataColumn dc in dataTable.Columns)
            {
                List<object> x = new List<object>();
                x = (from DataRow drr in dataTable.Rows select drr[dc.ColumnName]).ToList();
                lstproduct.Add(x);
            }
            return Json(lstproduct);
        }

        [NonAction]
        public void GenerateProductChart(ref DataTable dataTable)
        {
            double? sminimumprice = (from c in _smdbcontext.Products select (double)c.ProductPrice).Min();
            double? smaximumprice = (from c in _smdbcontext.Products select (double)c.ProductPrice).Max();

            //double? sminimumprice = 0;
            decimal maximumprice = Convert.ToDecimal(smaximumprice);
            decimal minimumprice = Convert.ToDecimal(sminimumprice);
            decimal midprice = maximumprice / 5;

            decimal prevprice = 0;
            for (decimal currentprice = minimumprice; currentprice < maximumprice; currentprice++)
            {
                prevprice = currentprice;

                currentprice = currentprice + midprice;
                var prodcount = _smdbcontext.Products
                        .Where(m => Convert.ToInt64(m.ProductPrice) < currentprice && Convert.ToInt64(m.ProductPrice) >= prevprice).Count();
                DataRow dr = dataTable.NewRow();

                dr["Data1"] = prevprice;
                dr["Data2"] = prodcount;
                dataTable.Rows.Add(dr);
            }
        }

        [NonAction]
        public void GenerateCustomerChart(ref DataTable dataTable)
        {
            double? sminimumprice = (from c in _smdbcontext.Customers select (double)c.SellingPrice).Min();
            double? smaximumprice = (from c in _smdbcontext.Customers select (double)c.SellingPrice).Max();

            decimal maximumprice = Convert.ToDecimal(smaximumprice);
            decimal minimumprice = Convert.ToDecimal(sminimumprice);
            decimal midprice = maximumprice / 5;

            decimal prevprice = 0;
            for (decimal currentprice = minimumprice; currentprice < maximumprice; currentprice++)
            {
                prevprice = currentprice;

                currentprice = currentprice + midprice;
                var prodcount = _smdbcontext.Customers
                        .Where(m => Convert.ToInt64(m.SellingPrice) < currentprice && Convert.ToInt64(m.SellingPrice) >= prevprice).Count();
                DataRow dr = dataTable.NewRow();

                dr["Data1"] = prevprice;
                dr["Data2"] = prodcount;
                dataTable.Rows.Add(dr);
            }
            //decimal nextprice = 0;
            //decimal currprice = 0;
            //for (decimal i = 0; i < 5; i++)
            //{
            //    nextprice = nextprice + midamount;
            //    var prodcount = _smdbcontext.Customers
            //            .Where(m => Convert.ToInt64(m.SellingPrice) <= nextprice && Convert.ToInt64(m.SellingPrice) > currprice).Count();
            //    DataRow dr = dataTable.NewRow();

            //    dr["Data1"] = nextprice;
            //    dr["Data2"] = prodcount;
            //    dataTable.Rows.Add(dr);
            //    currprice = nextprice;
            //}
        }
    }
}