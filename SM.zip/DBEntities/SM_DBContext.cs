﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using SM.Models;

namespace SM.DBEntities
{
    public partial class SM_DBContext : DbContext
    {
        public virtual DbSet<Customers> Customers { get; set; }
        public virtual DbSet<PaymentMethod> PaymentMethod { get; set; }
        public virtual DbSet<Products> Products { get; set; }
        public virtual DbSet<ServiceInfo> ServiceInfo { get; set; }
        public virtual DbSet<ServiceMessages> ServiceMessages { get; set; }
        public virtual DbSet<ServicePeriods> ServicePeriods { get; set; }

        public SM_DBContext(DbContextOptions<SM_DBContext> options)
        : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customers>(entity =>
            {
                entity.HasKey(e => e.CustomerId);

                entity.Property(e => e.BillNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Caddress)
                    .HasColumnName("CAddress")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Cstatus)
                    .HasColumnName("CStatus")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.InstallationDate).HasColumnType("datetime");

                entity.Property(e => e.MobileNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.SalesPerson)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.SellingPrice)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PaymentMethod>(entity =>
            {
                entity.HasKey(e => e.PaymentId);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Pstatus)
                    .HasColumnName("PStatus")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Products>(entity =>
            {
                entity.HasKey(e => e.ProductId);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Pdescription)
                    .HasColumnName("PDescription")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ProductCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ProductPrice)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Pstatus)
                    .HasColumnName("PStatus")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<ServiceInfo>(entity =>
            {
                entity.HasKey(e => e.ServiceId);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.SpareDetails)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Sstatus)
                    .HasColumnName("SStatus")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.TechnicianName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.VisitedDate).HasColumnType("datetime");

                entity.Property(e => e.WorkDescription)
                    .HasMaxLength(500)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ServiceMessages>(entity =>
            {
                entity.HasKey(e => e.MessageId);

                entity.Property(e => e.CreateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MessageText)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Smstatus)
                    .HasColumnName("SMStatus")
                    .HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<ServicePeriods>(entity =>
            {
                entity.HasKey(e => e.PeriodId);

                entity.Property(e => e.Createddate)
                    .HasColumnName("createddate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Mstatus)
                    .HasColumnName("mstatus")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.PeriodName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PeriodMonth)
                    .HasColumnName("PeriodMonth");
            });
        }
    }
}
